/*
typedef struct
{
    int times[3];
} Semaforo;

typedef struct
{
    int new_times[3];
    unsigned char id;
} Update;

typedef unsigned char ProtocolBytes[15];
typedef Semaforo *_Semafori[16];
*/
#include "TrafficDataTypes.h"

void UpdateTimes(_Semafori *_semafori, Update *_to_update)
{
    //for su tutti i semafori per aggiornare eventuali modifiche ai timers
    for (unsigned char l = 0; l < 16; l++)
    {
        if( l == (*_to_update).id)
        {
            for (unsigned char i = 0; i < 3; i++)
            {   
               (*(*_semafori)[l]).times[i] = (*_to_update).new_times[i];
            }
        }

                        /*        
                if( (*(*_semafori)[l]).times[i] != (*(*_semafori)[l]).new_times[i] ) //se avviene qualche cambiamento allora aggornero i tempi
                {

                    (*(*_semafori)[l]).times[i] = (*(*_semafori)[l]).new_times[i];
                }
                */
    }
}

void ChangeTrafficLight(Semaforo *_semafori[16], unsigned char *_n_semafori)
{
    //incrementando n_semafori quando il tempo ï¿½ 0 assicura che vengano saltati i semafori che non vengoo inizializzati dal raspberry, quindi inesistenti nell'incrocio
    //si usa il do while perchè al primo avvio n_semafori è 0 e un while lo escluderebbe come condizione di incremento, serve quindi solo per quando n_semafori è 0
    *_n_semafori = ((*_n_semafori) + 1) % 9;
    /*
    do
    {
        *_n_semafori = ((*_n_semafori) + 1) % 9;
    } while( (*(_semafori)[*_n_semafori]).times[0] == 0 );
    */
}


//Compone in un int un numero scomposto in due byte
int GetTime(unsigned char index, ProtocolBytes *_dataFromGateway)
{
    int tmp;
    struct
    {
        unsigned int Val : 7;
    } shortInt;

    shortInt.Val = *(_dataFromGateway[index + 3]) & 0x7F;
    tmp = shortInt.Val;
    tmp = (tmp << 7) & 0x80;

    shortInt.Val = *(_dataFromGateway[index + 2]) & 0x7F;
    tmp = tmp | shortInt.Val;

    return tmp;
}


//setta i timer dei semafori
void SetDefaultTimers(int rosso, int verde, int giallo, _Semafori *_semafori)
{
    for (unsigned char l = 0; l < 16; l++)
    {
        for (unsigned char i = 0; i < 3; i++)
        {
            switch (i)
            {
            case 0:
                (*(*(_semafori)[l])).times[i] = rosso;
                break;
            case 1:
                (*(*(_semafori)[l])).times[i] = verde;
                break;
            case 2:
                (*(*(_semafori)[l])).times[i] = giallo;
                break;
            }
        }
    }
}



//CONTEGGIO VEICOLI
void Conteggio(unsigned int _count, unsigned char *_motorcycle[4], unsigned char *_car[4], unsigned char *_truck[4], unsigned char index)
{
        if (_count >= 500)
        {
            *_motorcycle[index]=(*_motorcycle[index])+1;
        }
        if (_count >= 1500)
        {
            *_car[index]=*(_car[index])+1;
        }
        if (_count >= 3000)
        {
            *_truck[index]=*(_truck[index])+1;
        }
}